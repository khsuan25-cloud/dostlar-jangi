package uz.dostlar.jangi;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

/** Local Wi-Fi / hotspot networking for two-phone matches (no internet needed). */
public class NetBridge {
    static final int TCP_PORT = 8765;
    static final int UDP_PORT = 8766;

    private final Context ctx;
    private final WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final LinkedBlockingQueue<String> outQ = new LinkedBlockingQueue<>();

    private volatile boolean running = false;
    private volatile ServerSocket server;
    private volatile Socket sock;
    private volatile DatagramSocket discSock;
    private Thread writer;
    private WifiManager.MulticastLock mlock;
    private volatile String gameName = "Do'stlar Jangi";

    public NetBridge(Context c, WebView w) { ctx = c; web = w; }

    private void emit(String type, String data) {
        final String js = "window.__netEvent&&window.__netEvent(" + JSONObject.quote(type) + "," + JSONObject.quote(data == null ? "" : data) + ")";
        ui.post(() -> web.evaluateJavascript(js, null));
    }

    private void acquireLock() {
        try {
            WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null && mlock == null) { mlock = wm.createMulticastLock("dostlar-jangi"); mlock.setReferenceCounted(false); }
            if (mlock != null && !mlock.isHeld()) mlock.acquire();
        } catch (Exception ignored) { }
    }

    private void releaseLock() { try { if (mlock != null && mlock.isHeld()) mlock.release(); } catch (Exception ignored) { } }

    @JavascriptInterface
    public String localIp() {
        StringBuilder sb = new StringBuilder();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                        if (sb.length() > 0) sb.append(" / ");
                        sb.append(a.getHostAddress());
                    }
                }
            }
        } catch (Exception ignored) { }
        return sb.length() > 0 ? sb.toString() : "?";
    }

    private List<InetAddress> broadcastAddrs() {
        List<InetAddress> list = new ArrayList<>();
        try { list.add(InetAddress.getByName("255.255.255.255")); } catch (Exception ignored) { }
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress b = ia.getBroadcast();
                    if (b != null && !list.contains(b)) list.add(b);
                }
            }
        } catch (Exception ignored) { }
        try { InetAddress hs = InetAddress.getByName("192.168.43.255"); if (!list.contains(hs)) list.add(hs); } catch (Exception ignored) { }
        return list;
    }

    @JavascriptInterface
    public void host(String name) {
        close();
        gameName = name == null || name.isEmpty() ? "Do'stlar Jangi" : name;
        running = true;
        acquireLock();
        new Thread(() -> {
            try {
                ServerSocket ss = new ServerSocket();
                ss.setReuseAddress(true);
                ss.bind(new InetSocketAddress(TCP_PORT));
                server = ss;
                emit("hosting", localIp());
                Socket s = ss.accept();
                try { ss.close(); } catch (Exception ignored) { }
                server = null;
                attach(s);
            } catch (Exception e) {
                if (running) emit("error", "Server xatosi: " + e.getMessage());
            }
        }, "dj-accept").start();
        new Thread(() -> {
            DatagramSocket ds = null;
            try {
                ds = new DatagramSocket();
                ds.setBroadcast(true);
                byte[] msg = ("DJ|" + gameName).getBytes("UTF-8");
                while (running && sock == null) {
                    for (InetAddress b : broadcastAddrs()) {
                        try { ds.send(new DatagramPacket(msg, msg.length, b, UDP_PORT)); } catch (Exception ignored) { }
                    }
                    Thread.sleep(700);
                }
            } catch (Exception ignored) {
            } finally { if (ds != null) ds.close(); }
        }, "dj-beacon").start();
    }

    @JavascriptInterface
    public void discover() {
        close();
        running = true;
        acquireLock();
        new Thread(() -> {
            try {
                DatagramSocket ds = new DatagramSocket(null);
                ds.setReuseAddress(true);
                ds.setBroadcast(true);
                ds.bind(new InetSocketAddress(UDP_PORT));
                discSock = ds;
                byte[] buf = new byte[512];
                while (running && sock == null) {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    ds.receive(p);
                    String m = new String(p.getData(), 0, p.getLength(), "UTF-8");
                    if (m.startsWith("DJ|")) {
                        JSONObject o = new JSONObject();
                        o.put("name", m.substring(3));
                        o.put("ip", p.getAddress().getHostAddress());
                        emit("found", o.toString());
                    }
                }
            } catch (Exception e) {
                if (running && sock == null) emit("error", "Qidiruv xatosi: " + e.getMessage());
            }
        }, "dj-discover").start();
    }

    @JavascriptInterface
    public void join(final String ip) {
        new Thread(() -> {
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(ip.trim(), TCP_PORT), 5000);
                running = true;
                attach(s);
            } catch (Exception e) {
                emit("error", "Ulanib bo'lmadi (" + ip + "): " + e.getMessage());
            }
        }, "dj-join").start();
    }

    private void attach(Socket s) throws Exception {
        s.setTcpNoDelay(true);
        s.setKeepAlive(true);
        sock = s;
        try { if (discSock != null) discSock.close(); } catch (Exception ignored) { }
        discSock = null;
        final BufferedWriter out = new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), "UTF-8"));
        final BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
        outQ.clear();
        writer = new Thread(() -> {
            try {
                while (running && sock == s) {
                    String m = outQ.take();
                    if (sock != s) break;
                    out.write(m);
                    out.write('\n');
                    if (outQ.isEmpty()) out.flush();
                }
            } catch (Exception ignored) { }
        }, "dj-writer");
        writer.start();
        new Thread(() -> {
            try {
                String line;
                while ((line = in.readLine()) != null) emit("msg", line);
            } catch (Exception ignored) { }
            if (running && sock == s) { running = false; emit("closed", "eof"); }
        }, "dj-reader").start();
        emit("connected", s.getInetAddress().getHostAddress());
    }

    @JavascriptInterface
    public void send(String m) { if (sock != null && m != null) outQ.offer(m); }

    @JavascriptInterface
    public void close() {
        running = false;
        try { if (sock != null) sock.close(); } catch (Exception ignored) { }
        try { if (server != null) server.close(); } catch (Exception ignored) { }
        try { if (discSock != null) discSock.close(); } catch (Exception ignored) { }
        sock = null; server = null; discSock = null;
        if (writer != null) writer.interrupt();
        writer = null;
        outQ.clear();
        releaseLock();
    }
}
