# Do'stlar Jangi — Android (APK)

O'yinning o'zi: `app/src/main/assets/index.html` (bitta fayl, internet kerak emas).

## 1-yo'l: GitHub orqali (kompyuterda hech narsa o'rnatmasdan)
1. github.com da yangi repository oching va shu papkadagi hamma fayllarni yuklang.
2. **Actions** bo'limida "APK yasash" avtomatik ishga tushadi (~5 daqiqa).
3. Tugagach, o'sha ishga tushirish sahifasining pastidagi **DostlarJangi-apk** ni yuklab oling — ichida APK bor.
4. APK ni telefonga tashlab o'rnating (sozlamalarda "Noma'lum manbalardan o'rnatish"ga ruxsat bering).

## 2-yo'l: Android Studio
Papkani Android Studio'da oching → Build → Build APK(s).

## Ikki telefonda o'ynash (Wi-Fi yoki hotspot)
1. APK ni ikkala telefonga o'rnating.
2. Ikkala telefonni bitta Wi-Fi ga ulang. Yoki bitta telefonda "Tochka dostupa" (hotspot) ni yoqing, ikkinchisini unga ulang.
3. Bosh menyuda **WI-FI JANG** ni bosing.
4. Birinchi telefon: **O'YIN YARATISH**. Ekranda uning IP manzili chiqadi.
5. Ikkinchi telefon: **QO'SHILISH**. O'yin ro'yxatda o'zi chiqadi, ustiga bosing.
   Chiqmasa, **IP BILAN ULANISH** ni bosib, birinchi telefondagi IP ni yozing
   (hotspot yoqqan telefon odatda 192.168.43.1 bo'ladi).
6. Har kim o'z qahramonini tanlaydi, host arenani tanlaydi, ikkalasi **TAYYOR** ni bosadi.
